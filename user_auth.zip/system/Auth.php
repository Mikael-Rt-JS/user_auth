<?php

class Auth{
    public static function who_auth(){
        if(isset($_SESSION['admin_id'])){
            self::go_to("Location: http://localhost/user_auth/admin");
        }
        if(isset($_SESSION['user_id'])){
            self::go_to("Location: http://localhost/user_auth/user");
        }
    }

    public static function go_to($location){
        header($location); // Перенаправление на страницу пользователя
        exit();
    }
}