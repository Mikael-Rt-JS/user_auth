let $=ip=>document.querySelector(`${ip}`);
let log=console.log
let dir=console.dir

function empty_html(objElKey){
	if(typeof objElKey==='object'){
		if(Array.isArray(objElKey)){
			for (let i=0; i<objElKey.length;i++) {
				$(`.${objElKey[i]}`).innerHTML=''
			}
		}else{
			for (let [key,val] of Object.entries(objElKey)) {
				$(`.${key}`).innerHTML=''
			}
		}
		
	}
}