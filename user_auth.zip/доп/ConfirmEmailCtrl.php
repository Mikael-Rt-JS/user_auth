<?php

class ConfirmEmailCtrl {
	public $title='CITADEL MINI-FRAMEWORK';
	
	public function index() {
		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		//var_dump($rows);
		
		
		// переходим к представлению
		include './citadel/views/signin.php';
    }
	/*
    public function index() {
		global $connection;
		if(array_key_exists('user_signin',$_SESSION)){
			header('Location: http://localhost/foryourbusiness/user');
			exit();
		}else{
			//$ssk=password_hash($_SESSION['ss_key'],PASSWORD_DEFAULT);
			if(array_key_exists('ss_key_check',$_SESSION)){
				if($_SESSION['ss_key']==$_SESSION['ss_key_check']){
					unset($_SESSION['ss_key']);
					unset($_SESSION['ss_key_check']);
					$this->add_user();
					header('Location: http://localhost/foryourbusiness/user');
				}else{
					include './citadel/views/confirm_email.php';
				}
			}else{
				include './citadel/views/confirm_email.php';
			}
		}
		
    }

	public function test(){
		echo '0o0';
	}
	
	public function check_ssk(){
		$ssk_user=json_decode(file_get_contents("php://input"),true);
		$ssk=$_SESSION['ss_key'];
		$_SESSION['ss_key_check']=$ssk_user["sec_code"];
		$_SESSION['eye']=$ssk_user;
		
		if($ssk==$ssk_user["sec_code"]){
			unset($_SESSION['ss_key']);
			$this->add_user();
			header('Location: http://localhost/foryourbusiness/user');
			exit();
		}else{
			$_SESSION['ss_key_err']="Неверно ввели секретный код!!!";
			header('Location: http://localhost/foryourbusiness/confirm_email');
			exit();
		}
	}
	
	public function add_user(){
		global $connection;
		//$_SESSION['user_signup'];
		

		$name=$_SESSION['user_signup']["name"];
		$surname=$_SESSION['user_signup']["surname"];
		$email=$_SESSION['user_signup']["email"];
		$password=$_SESSION['user_signup']["password"];
		$phone=$_SESSION['user_signup']["phone"];
		$role=$_SESSION['user_signup']["role"];
		$director_id=$_SESSION['user_signup']["director_id"];
		$tariff_plan=$_SESSION['user_signup']["tariff_plan"];
		$tariff_expires_at=$_SESSION['user_signup']["tariff_expires_at"];
		$companie_id=$_SESSION['user_signup']["companie_id"];
		$active=$_SESSION['user_signup']["active"];
		
		$stmt = $connection->prepare("INSERT INTO users (name,surname,email,password,phone,role,director_id,tariff_plan,tariff_expires_at,companie_id,active ) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sss", $name,$surname,$email,$password,$phone,$role,$director_id,$tariff_plan,$tariff_expires_at,$companie_id,$active);
		if($stmt->execute()){
			$_SESSION['user_signin']=$connection->insert_id;
			header('Location: http://localhost/foryourbusiness/user');
			exit();
		}else{
			unset($_SESSION['user_signin']);
			//var_dump(3432);
		}
	}
	*/
}