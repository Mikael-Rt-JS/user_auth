<?php

class SigninCtrl {
	public $title='CITADEL MINI-FRAMEWORK';
	
	public function index() {
		Auth::who_auth();

		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		//var_dump($rows);
		
		
		// переходим к представлению
		include './citadel/views/signin.php';
    }

	public function signin_submit(){
		global $connection;

		// Получаем данные из формы
		$email = $_POST['email'];
		$password = $_POST['password'];

		try {
			// Подготовленный запрос для проверки пользователя по email
			$stmt = $connection->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
			$stmt->bindParam(':email', $email, PDO::PARAM_STR);
			$stmt->execute();
		
			// Проверяем, найден ли пользователь с таким email
			if ($stmt->rowCount() > 0) {
				$user = $stmt->fetch(PDO::FETCH_ASSOC);
		
				// Проверяем совпадение пароля
				// Здесь предполагается, что пароль в базе данных захеширован
				if (password_verify($password, $user['password'])) {
					// Успешный вход - устанавливаем сессионные данные
					$_SESSION['user_id'] = $user['id'];
					$_SESSION['email'] = $user['email'];
		
					// Перенаправляем на личную страницу или другую страницу
					header('Location: http://localhost/user_auth/user');
					exit();
				} else {
					// Неверный пароль
					$_SESSION['errors']['password'] = 'Неверный пароль.';
					header('Location: http://localhost/user_auth/signin');
					exit();
				}
			} else {
				// Пользователь не найден
				$_SESSION['errors']['email'] = 'Пользователь с таким email не найден.';
				header('Location: http://localhost/user_auth/signin');
				exit();
			}
		} catch (PDOException $e) {
			// Обработка ошибок
			echo 'Ошибка: ' . $e->getMessage();
		}

	}
}