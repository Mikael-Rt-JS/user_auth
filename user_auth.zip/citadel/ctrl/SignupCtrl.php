<?php

class SignupCtrl {
	public $title='CITADEL MINI-FRAMEWORK';
	
	public function index() {
		Auth::who_auth();

		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		
		
		// переходим к представлению
		include './citadel/views/signup.php';
    }
	
	public function signup_submit(){
		global $connection;
		$validator = new Validate();
		// Проверяем все поля
		$validator->validateName($_POST['name'] ?? '')
		->validatePhone($_POST['phone'] ?? '')
		->validateEmail($_POST['email'] ?? '')
		->validatePassword($_POST['password'] ?? '')
		->validateRepeatPassword($_POST['password'] ?? '', $_POST['repeat_password'] ?? '');

		// Проверяем наличие ошибок
		if ($validator->hasErrors()) {
			// Если ошибки есть, сохраняем их в сессии и редиректим обратно
			$validator->storeErrorsInSession();
			header("Location: http://localhost/user_auth/signup"); // Редирект на страницу регистрации
			exit();
		} else {
			// Если ошибок нет, записываем данные в базу данных
			//$db = Database::getInstance();

			// Подготовка данных для вставки
			$data = [
				'name' => $_POST['name'],
				'phone' => $_POST['phone'],
				'email' => $_POST['email'],
				'password' => password_hash($_POST['password'], PASSWORD_DEFAULT), // Хешируем пароль
			];

			MySQL::insertUser($connection,$data);

			// Получаем ID последней вставленной записи
			$user_id=$connection->lastInsertId();
			$_SESSION['user_id']=$user_id;

			// Очищаем ошибки из сессии и перенаправляем на страницу с успешной регистрацией
			$validator->clearErrorsFromSession();
			header("Location: http://localhost/user_auth/user"); // Перенаправление на страницу успеха
			exit();
		}
		
	}

}
