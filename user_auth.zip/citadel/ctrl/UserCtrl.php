<?php

class UserCtrl {
	public $title='User page';
	
	
    public function index() {
		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		//var_dump($rows);
		
		
		// переходим к представлению
		include './citadel/views/user.php';
    }

	public function test(){
		echo '0o0';
	}
	
	/*
    public function index() {
		global $connection;
		if(array_key_exists('user_signin',$_SESSION)){
			$userInfo=$this->getUser($connection,$_SESSION['user_signin']);
		
			//var_dump($userInfo);
			
			// echo "GET - Главная страница";
			
			// переходим к представлению
			include './citadel/views/user.php';
		}else{
			header('Location: http://localhost/foryourbusiness/signin');
			exit();
		}
    }

	public function test(){
		echo '0o0';
	}
	
	public function getUser($connection){
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		return $rows;
	}
	*/
}