<?php require_once __DIR__.'/global/doctype_open.php'; ?>
	  
	<!-- FONTS -->
  
	<!-- Inter&Rubik Moonrocks -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Rubik+Moonrocks&display=swap" rel="stylesheet">
  
	<link href="./static/css/globals/reset.css" rel="stylesheet" text="text/css"/>
	<link href="./static/css/globals/globals.css" rel="stylesheet" text="text/css"/>

</head>
<body>

	<h1>Signin page</h1>
		<form class="" action="#" method="POST">
			<div class="input_box-ctrl">
				<label for="email">Your email:</label>
				<input value="tes43534@mail.com" type="text" name="email" id="email" placeholder="Your email:"/>
				<?php if (isset($_SESSION['errors']['email'])): ?>
					<p class="err err_email">
						<?php echo $_SESSION['errors']['email']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="password">Password:</label>
				<input value="tet789t" type="password" name="password" id="password" placeholder="Password:"/>
				<?php if (isset($_SESSION['errors']['password'])): ?>
					<p class="err err_password">
						<?php echo $_SESSION['errors']['password']; ?>
					</p>
				<?php endif; ?>
			</div>
			<button class="signin_btn">Signin</button>
		</form>
<?php require_once __DIR__.'/global/doctype_close.php'; ?>