<?php require_once __DIR__.'/global/doctype_open.php'; ?>
	  
	<!-- FONTS -->
  
	<!-- Inter&Rubik Moonrocks -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Rubik+Moonrocks&display=swap" rel="stylesheet">
  
	<link href="./static/css/globals/reset.css" rel="stylesheet" text="text/css"/>
	<link href="./static/css/globals/globals.css" rel="stylesheet" text="text/css"/>
	<style>
	form{
  margin: 50px auto;
  max-width: 500px;
  padding: 20px;
  border: 1px solid black;
  border-radius: 6px;
  
  font-family: Arial, sans-serif;
  border: 1px solid #c0c0c0;
  
}

form div{
  display: flex;
  flex-direction: column;
  margin-bottom: 10px;
  gap: 10px;
  
}

form label{
  padding-left: 10px;
  font-size: 12px;
  font-weight: bold;
  color: #32BDF9;
  
}
input, textarea, select{
  flex-grow: 1;
  
  font-size: 16px;
  padding: 10px 10px;
  cursor: pointer;
  font-weight: 600;
  border: 1px solid #E5E5E5;
  /* color: #FFFFFF; */
  color: #020202;
  background: #00000010;
  transition: all 0.6s;
}
input, select{
  border-radius: 6px;
}

input::placeholder,
select::placeholder{
	color: #E4E0E0;
}

input:focus,
textarea:focus,
select:focus{
  outline: none;
}

input:hover,
textarea:hover,
select:hover{
  background: #00000020;
  transition: all ease 0.6s;
}

form .err{
  font-size: 12px;
  padding-left: 25px;
  margin: 0;
  color: rgb(240,85,25);
  font-weight: bold;
}

form .signup_btn{
  background: transparent;
  display: block;
  text-transform: uppercase;
  font-size: 16px;
  font-weight: bold;
  width: 100%;
  padding: 10px;
  border-radius: 6px;
  cursor: pointer;
  color: #c0c0c0;
  border: 1px solid #c0c0c0;
}

	</style>

</head>
<body>
	
		<form class="" action="#" method="POST">
			<div class="input_box-ctrl">
				<label for="name">Your name:</label>
				<input value="test" type="text" name="name" id="name" placeholder="Your name:"/>
				<?php if (isset($_SESSION['errors']['name'])): ?>
					<p class="err err_name">
						<?php echo $_SESSION['errors']['name']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="phone">Your phone:</label>
				<input value="+37443858699" type="text" name="phone" id="phone" placeholder="Your phone"/>
				<?php if (isset($_SESSION['errors']['phone'])): ?>
					<p class="err err_phone">
						<?php echo $_SESSION['errors']['phone']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="email">Your email:</label>
				<input value="tes43534@mail.com" type="text" name="email" id="email" placeholder="Your email:"/>
				<?php if (isset($_SESSION['errors']['email'])): ?>
					<p class="err err_email">
						<?php echo $_SESSION['errors']['email']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="password">Password:</label>
				<input value="tet789t" type="password" name="password" id="password" placeholder="Password:"/>
				<?php if (isset($_SESSION['errors']['password'])): ?>
					<p class="err err_password">
						<?php echo $_SESSION['errors']['password']; ?>
					</p>
				<?php endif; ?>
			</div>
					
			<div class="input_box-ctrl">
				<label for="repeat_password">Password repeat:</label>
				<input value="tet789t" type="password" name="repeat_password" id="repeat_password" placeholder="Password repeat:"/>
				<?php if (isset($_SESSION['errors']['repeat_password'])): ?>
					<p class="err err_repeat_password">
						<?php echo $_SESSION['errors']['repeat_password']; ?>
					</p>
				<?php endif; ?>
			</div>
			<button class="signup_btn">Signup</button>
		</form>
	
	<!-- <img src="./static/images/azariel-titan-wallpaper-3840px.jpg"  alt="azariel-titan-wallpaper-3840px" title="azariel-titan-wallpaper-3840px"/> -->
	<!--
	<script src="./static/js/globals.js"></script>
	<script src="./static/js/signup/signup.js"></script>
	-->
	<script>
/*
<div class="input_box-ctrl">
				<label for="age">Your age:</label>
				<input value="27" type="number" name="age" id="age" placeholder="Your age"/>
<!-- 				<p class="err err_age"></p> -->
			</div>



<div class="input_box-ctrl">
				<label for="name">Your name:</label>
				<input type="text" name="name" id="name" placeholder="Your name:"/>
<!-- 				<p class="err err_name"></p> -->
			</div>
					
			<div class="input_box-ctrl">
				<label for="surname">Your surname:</label>
				<input type="text" name="surname" id="surname" placeholder="Your surname:"/>
<!-- 				<p class="err err_surname"></p> -->
			</div>
					
			<div class="input_box-ctrl">
				<label for="phone">Your phone:</label>
				<input type="text" name="phone" id="phone" placeholder="Your phone"/>
<!-- 				<p class="err err_phone"></p> -->
			</div>
					
			<div class="input_box-ctrl">
				<label for="email">Your email:</label>
				<input type="text" name="email" id="email" placeholder="Your email:"/>
<!-- 				<p class="err err_email"></p> -->
			</div>
					
			<div class="input_box-ctrl">
				<label for="password">Password:</label>
				<input type="password" name="password" id="password" placeholder="Password:"/>
<!-- 				<p class="err err_password"></p> -->
			</div>
					
			<div class="input_box-ctrl">
				<label for="repeat_password">Password repeat:</label>
				<input type="password" name="repeat_password" id="repeat_password" placeholder="Password repeat:"/>
				<p class="err err_repeat_password">Err</p>
			</div>
					
			<div class="input_box-ctrl">
				<label for="role">Role:</label>
				<select name="role" id="role">
					<option value="directore">Director</option>
					<option value="employee">Employee</option>
				</select>
<!-- 			  <p class="err err_msg"></p> -->
			</div>

*/
</script>
	
<?php require_once __DIR__.'/global/doctype_close.php'; ?>