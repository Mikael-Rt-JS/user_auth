const signup_form=$(`#signup_form`)

signup_form.addEventListener("submit", async function (event) {
    event.preventDefault();
	const saltRounds = 10;
	empty_html([
		//'err_company_name',
		'err_name',
		'err_surname',
		'err_phone',
		// 'err_telegram_id',
		'err_email',
		'err_password',
		'err_repeat_password'
	])
	
    let isValid = true;
    let errors = {};

    //const companyName = signup_form.company_name.value.trim();
    const name = signup_form.name.value.trim();
    const surname = signup_form.surname.value.trim();
    const phone = signup_form.phone.value.trim();
    //const telegramId = signup_form.telegram_id.value.trim();
    const email = signup_form.email.value.trim();
    const password = signup_form.password.value.trim();
    const repeatPassword = signup_form.repeat_password.value.trim();
    const role = signup_form.role.value;

    /*if (!companyName) {
		errors.err_company_name='Введите название компании'
    }*/
	if (!name) {
		errors.err_name='Введите имя'
    }
	if (!surname) {
		errors.err_surname='Введите фамилию'
    }
	if (!phone) {
		errors.err_phone='Введите телефон'
    }
	
	if (!/^\d+$/.test(phone)){
		errors.err_phone='Телефон должен содержать только цифры'
    }
	if (!email) {
		errors.err_email='Введите ваш Email'
    }
	/*
	if (!telegramId) {
		errors.err_telegram_id='Введите Telegram ID'
    }
	*/
	
    if (!password) {
		errors.err_password='Введите пароль'
    } else if (password.length < 6) {
		errors.err_password='Пароль должен быть не менее 6 символов'
    }

    if (password !== repeatPassword) {
		errors.err_repeat_password='Пароли не совпадают'
    }
	
	// hash pass
	
	
	if (Object.keys(errors).length === 0) {
		let date =new Date()
		//getAllDate(db,table_name,ref,onValue)
		const secretCode = Math.floor(100000 + Math.random() * 900000);
		
		let result=$('.err_msg')
		
		result.innerHTML=''
		//signup_form.submit(); // Убирай эту строку, если не хочешь реальной отправки
		let res=await fetch('https://api.web3forms.com/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
				access_key: signup_form.access_key.value.trim(),
				// company_name:companyName,
				name: name,
				surname: surname,
				phone: phone,
				email:email,
				role: role,
				msg: `Уважаемый ,
Ваш код: ${secretCode}. Используйте его для доступа к своему аккаунту.

Если вы этого не запрашивали, просто проигнорируйте это сообщение.

С уважением,
Команда ForYourBusiness
-------------------------
Dear ,

Your code is: ${secretCode}. Use it to access your account.

If you didn't request this, simply ignore this message.

Yours,
The ForYourBusiness Team`
})
		}).then(async (response) => {
            let json = await response.json();
            if (response.status == 200) {
                result.innerHTML = json.message;
				//window.location.href='./confirm_email.html'
				
				// 
				return response.status
            } else {
                result.innerHTML = json.message;
            }
        })
        .catch(error => {
			// "Something went wrong!"
            result.innerHTML = "Что-то пошло не так!";
        }) // fetch end
       
	   if(await res===200 || await res===302){
		   let redirect=await fetch('http://localhost/foryourbusiness/signup', {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'Accept': 'application/json'
				},
				body: JSON.stringify({
					name: name,
					surname: surname,
					email:email,
					password: password,
					phone: phone,
					role: role,
					director_id: 0,
					tariff_plan: '',
					tariff_expires_at: "0000-00-00",
					companie_id: 0,
					active: 0,
					ss_code: secretCode
				})
			}).then(res=>res.json())
			.then(data=>data)
			.catch(err => {
				// "Something went wrong!"
				console.log(err)
			})//fetch end
			
			if(await redirect){
				location.href=redirect.page
			}
		}else{
				console.log(res)
		}
		//alert("Форма успешно отправлена!");
    } else {
		// выводит ошибки полей
		for (let [key,val] of Object.entries(errors)) {
			$(`.${key}`).innerHTML=val
		}
    }
	
 });