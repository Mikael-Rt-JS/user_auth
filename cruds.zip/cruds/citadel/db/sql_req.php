<?php

// Подготовка данных для вставки
$data = [
    'name' => $_POST['name'],
    'phone' => $_POST['phone'],
    'email' => $_POST['email'],
    'password' => password_hash($_POST['password'], PASSWORD_DEFAULT), // Хешируем пароль
];

/*
// TABLE: 
$=[
    ''=>$_POST[''],
    ''=>$_POST['']

];
*/

// TABLE: admins
$admins=[
    'name'=>$_POST['name'],
    'status'=>$_POST['status'],
    'phone'=>$_POST['phone'],
    'email'=>$_POST['email'],
    'password'=> password_hash($_POST['password'], PASSWORD_DEFAULT),
    'was'=>$_POST['was']
];

// TABLE: products
$products=[
    'name'=>$_POST['name'],
    'barcode'=>$_POST['barcode'],
    'images'=>$_POST['images'],
    'user_id'=>$_POST['user_id']

];

// TABLE: product_expirations
$product_expirations=[
    'product_id'=>$_POST['product_id'],
    'expiration_date'=>$_POST['expiration_date'],
    'added_by'=>$_POST['added_by']
];

// TABLE: users
$users=[
    'name'=>$_POST['name'],
    'surname'=>$_POST['surname'],
    'email'=>$_POST['email'],
    'verify_email'=>$_POST['verify_email'],
    'password'=> password_hash($_POST['password'], PASSWORD_DEFAULT),
    'phone'=>$_POST['phone'],
    'role'=>$_POST['role'],
    'director_id'=>$_POST['director_id'],
    'tariff_plan'=>$_POST['tariff_plan'],
    'tariff_expires_at'=>$_POST['tariff_expires_at'],
    'companie_id'=>$_POST['companie_id'],
    'active'=>$_POST['active']
];

// TABLE: companies
$companies=[
    'companie_name'=>$_POST['companie_name'],
    'user_id'=>$_POST['user_id']
];

// TABLE: users_info
$users_info=[
    'user_id'=>$_POST['user_id'],
    'country'=>$_POST['country'],
    'city'=>$_POST['city'],
    'address'=>$_POST['address'],
    'post_index'=>$_POST['post_index']
];

// TABLE: tariff_history
$tariff_history=[
    'user_id'=>$_POST['user_id'],
    'amount'=>$_POST['amount'],
    'payment_method'=>$_POST['payment_method'],
    'tariff_plan'=>$_POST['tariff_plan'],
    'companie_id'=>$_POST['companie_id']
];

// TABLE: tariffs
$tariffs=[
    'plan'=>$_POST['plan'],
    'price'=>$_POST['price'],
    'duration_months'=>$_POST['duration_months'],
    'role'=>$_POST['role']
];

/*
$sql = "INSERT INTO s (,,,) 
VALUES (:,:,:,:)";

$sql = "INSERT INTO s (name,status,phone,email,password,was) 
VALUES (:name,:status,:phone,:email,:password,was)";

$sql = "INSERT INTO products (name,barcode,images,user_id) 
VALUES (:name,:barcode,:images,:user_id)";

$sql = "INSERT INTO product_expirations (product_id,expiration_date,added_by) 
VALUES (:product_id,:expiration_date,:added_by)";

$sql = "INSERT INTO users (name,surname,email,verify_email,password,phone,role,director_id,tariff_plan,tariff_expires_at,companie_id,active) 
VALUES (:name,:surname,:email,:verify_email,:password,:phone,:role,:director_id,:tariff_plan,:tariff_expires_at,:companie_id,:active)";

$sql = "INSERT INTO companies (companie_name,user_id)
VALUES (:companie_name,:user_id))";

$sql = "INSERT INTO users_info (user_id,country,city,address,) 
VALUES (:user_id,:country,:city,:address,:post_index)";

$sql = "INSERT INTO tariff_historys (user_id,amount,payment_method,tariff_plan,companie_id) 
VALUES (:user_id,:amount,:payment_method,:tariff_plan,:companie_id)";

$sql = "INSERT INTO tariffs (plan,price,duration_months,role) 
VALUES (:plan,:price,:duration_months,:role)";

*/


// ================================================= USER

// +++ OK - Нет компании, нет директора (NULL)
SELECT u.*, c.company_name 
FROM users u LEFT JOIN companies c 
ON u.company_id = c.id 
WHERE u.id = 2 AND u.role = 'employee' AND (u.director_id = -3 OR u.director_id IS NULL);

SELECT u.*, c.company_name 
FROM users u LEFT JOIN companies c 
ON u.company_id = c.id 
WHERE u.id = 5 AND u.role = 'director' AND (u.director_id IS NULL);



// +++ OK - Нет компании, есть директор & Есть компания, есть директор

SELECT u.*, c.company_name 
FROM users u
LEFT JOIN companies c ON u.company_id = c.id
WHERE u.id = 4 AND u.role = 'employee' AND (u.director_id = 3 OR u.director_id IS NULL);

SELECT u.*, c.company_name 
FROM users u
LEFT JOIN companies c ON u.company_id = c.id
WHERE u.id = 6 AND u.role = 'employee' AND (u.director_id = 3 OR u.director_id IS NULL);




