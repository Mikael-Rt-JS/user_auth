<?php
class MySQL {
    private static $instance = null; // Единственный экземпляр
    private $connection; // Соединение с базой данных
    private $host = 'localhost'; // Хост
    private $dbname = 'for_your_business'; // Название базы данных к примеру test 
    private $username = 'root'; // Имя пользователя
    private $password = ''; // Пароль

    // Закрытый конструктор для предотвращения создания новых экземпляров
    private function __construct() {
        try {
            // Создание соединения с базой данных
            $this->connection = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->username, $this->password);
            // Установка режима ошибок для PDO
            $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die('Ошибка подключения: ' . $e->getMessage());
        }
    }

    // Метод для получения экземпляра
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Получить соединение
    public function getConnection() {
        return $this->connection;
    }

    // Защищаем от клонирования объекта
    private function __clone() {}

    // Защищаем от уничтожения объекта
    // protected function __wakeup() {}

    public static function insertCompany($connection,$dataCompany){
        $sql = "INSERT INTO companies (company_name) 
        VALUES (:company_name)";
    
        // Если ошибок нет, записываем данные в базу данных
        $stmt=$connection->prepare($sql);
        // Запись в таблицу "users"
        $stmt->execute([
            ':company_name' => $dataCompany['company_name'],
        ]);

    }

    public static function updateCompany($connection,$company_id,$user_id){
        $sqlCompanyUpdate = "UPDATE companies SET user_id = :user_id WHERE id = :company_id";
        $stmtCompanyUpdate = $connection->prepare($sqlCompanyUpdate);
        $stmtCompanyUpdate->bindParam(':company_id', $company_id, PDO::PARAM_INT);
        $stmtCompanyUpdate->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmtCompanyUpdate->execute();
    }

    public static function insertUserDi($connection,$data){
        $sql = "INSERT INTO users (name,surname, phone, email, password, role, company_id) 
        VALUES (:name,:surname, :phone, :email, :password, :role, :company_id)";
    
        // Если ошибок нет, записываем данные в базу данных
        $stmt=$connection->prepare($sql);
        // Запись в таблицу "users"
        $stmt->execute([
            ':name' => $data['name'],
            ':surname' => $data['surname'],
            ':phone' => $data['phone'],
            ':email' => $data['email'],
            ':password' => $data['password'],  // Уже хешированный пароль
            ':role'=> $data['role'],
			':company_id'=>$data['company_id']
        ]);

    }


    public static function insertUserEmp($connection,$data){
        $sql = "INSERT INTO users (name,surname, phone, email, password,role, director_id, company_id) 
        VALUES (:name,:surname,:phone,:email,:password,:role,:director_id, :company_id)";
    
        // Если ошибок нет, записываем данные в базу данных
        $stmtUser=$connection->prepare($sql);
        // Запись в таблицу "users"
        $stmtUser->bindParam(':name', $data['name'], PDO::PARAM_STR);
        $stmtUser->bindParam(':surname', $data['surname'], PDO::PARAM_STR);
        $stmtUser->bindParam(':email', $data['email'], PDO::PARAM_STR);
        $stmtUser->bindParam(':password', $data['password'], PDO::PARAM_STR);
        $stmtUser->bindParam(':phone', $data['phone'], PDO::PARAM_STR);
        $stmtUser->bindParam(':role', $data['role'], PDO::PARAM_STR);
        $stmtUser->bindParam(':director_id', $data['director_id'], PDO::PARAM_INT);
        $stmtUser->bindParam(':company_id', $data['company_id'], PDO::PARAM_INT);
        $stmtUser->execute();
    }

}

/*
// Использование:
$db = Database::getInstance(); // Получаем единственный экземпляр базы данных
$connection = $db->getConnection(); // Получаем соединение

// Пример запроса к базе данных
$query = $connection->query('SELECT * FROM users');
$rows = $query->fetchAll(PDO::FETCH_ASSOC);
print_r($rows);
*/

//INSERT INTO `test` (`id`, `name`, `age`, `password`, `signup_date`) VALUES (NULL, 'kozel', '23', 'kozel23', current_timestamp());