<?php require_once __DIR__.'/global/doctype_open.php'; ?>
	<!-- FONTS -->
  
	<!-- Inter&Rubik Moonrocks -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Rubik+Moonrocks&display=swap" rel="stylesheet">
  
	<link href="./static/css/globals/reset.css" rel="stylesheet" text="text/css"/>
	<link href="./static/css/globals/globals.css" rel="stylesheet" text="text/css"/>
	<style>
	form{
  margin: 50px auto;
  max-width: 500px;
  padding: 20px;
  border: 1px solid black;
  border-radius: 6px;
  
  font-family: Arial, sans-serif;
  border: 1px solid #c0c0c0;
  
}

form div{
  display: flex;
  flex-direction: column;
  margin-bottom: 10px;
  gap: 10px;
  
}

form label{
  padding-left: 10px;
  font-size: 12px;
  font-weight: bold;
  color: #32BDF9;
  
}
input, textarea, select{
  flex-grow: 1;
  
  font-size: 16px;
  padding: 10px 10px;
  cursor: pointer;
  font-weight: 600;
  border: 1px solid #E5E5E5;
  /* color: #FFFFFF; */
  color: #020202;
  background: #00000010;
  transition: all 0.6s;
}
input, select{
  border-radius: 6px;
}

input::placeholder,
select::placeholder{
	/* color: #E4E0E0; */
	color:rgb(107, 106, 106);
}

input:focus,
textarea:focus,
select:focus{
  outline: none;
}

input:hover,
textarea:hover,
select:hover{
  background: #00000020;
  transition: all ease 0.6s;
}

form .err{
  font-size: 12px;
  padding-left: 25px;
  margin: 0;
  color: rgb(240,85,25);
  font-weight: bold;
}

form .signup_btn{
  background: transparent;
  display: block;
  text-transform: uppercase;
  font-size: 16px;
  font-weight: bold;
  width: 100%;
  padding: 10px;
  border-radius: 6px;
  cursor: pointer;
  color: #c0c0c0;
  border: 1px solid #c0c0c0;
}
	</style>

</head>
<body>
	
		<form class="" action="http://localhost/cruds/signup" method="POST">
			<!--  -->
			<input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>" />

			<div class="input_box-ctrl">
				<label for="name">Your name:</label>
				<input value="test20" type="text" name="name" id="name" placeholder="Your name:"/>
				<?php if (isset($_SESSION['errors']['name'])): ?>
					<p class="err err_name">
						<?php echo $_SESSION['errors']['name']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="surname">Your name:</label>
				<input value="test202" type="text" name="surname" id="surname" placeholder="Your surname:"/>
				<?php if (isset($_SESSION['errors']['surname'])): ?>
					<p class="err err_surname">
						<?php echo $_SESSION['errors']['surname']; ?>
					</p>
				<?php endif; ?>
			</div>
			<div class="input_box-ctrl">
				<label for="phone">Your phone:</label>
				<input value="+37493000005" type="text" name="phone" id="phone" placeholder="Your phone"/>
				<?php if (isset($_SESSION['errors']['phone'])): ?>
					<p class="err err_phone">
						<?php echo $_SESSION['errors']['phone']; ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="input_box-ctrl">
				<label for="email">Your email:</label>
				<input value="test20test202@mail.yahoo" type="text" name="email" id="email" placeholder="Your email:"/>
				<?php if (isset($_SESSION['errors']['email'])): ?>
					<p class="err err_email">
						<?php echo $_SESSION['errors']['email']; ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="input_box-ctrl">
				<label for="password">Password:</label>
				<input value="test20est202" type="password" name="password" id="password" placeholder="Password:"/>
				<?php if (isset($_SESSION['errors']['password'])): ?>
					<p class="err err_password">
						<?php echo $_SESSION['errors']['password']; ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="input_box-ctrl">
				<label for="repeat_password">Password repeat:</label>
				<input value="test20est202" type="password" name="repeat_password" id="repeat_password" placeholder="Password repeat:"/>
				<?php if (isset($_SESSION['errors']['repeat_password'])): ?>
					<p class="err err_repeat_password">
						<?php echo $_SESSION['errors']['repeat_password']; ?>
					</p>
				<?php endif; ?>
			</div>

			<div class="input_box-ctrl">
				<label for="role">Your Role:</label>
				<select name="role" id="role">
					<option value="director">Director</option>
					<option value="employee">Employee</option>
				</select>
			</div>

			<div class="input_box-ctrl">
				<label for="director_id">Director ID:</label>
				<input type="number" name="director_id" id="director_id" placeholder="Director ID"/>
				<p class="err err_director-ctrl"></p>
			</div>

			<div class="input_box-ctrl">
				<label for="company_name">Company name:</label>
				<input value="ZomPackmon" type="text" name="company_name" id="company_name" placeholder="Company name"/>
				<p class="err err_company_name"></p>
			</div>

			<div class="input_box-ctrl">
				<label for="company_id">Company ID:</label>
				<input type="number" name="company_id" id="company_id" placeholder="Company ID"/>
				<p class="err err_company_id"></p>


				<div style="background-color: rgba(255, 235, 59, 0.6);color: #333333;padding: 10px;border-radius: 6px;display: flex;align-items: center;max-width: 100%;box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1), inset 0px 4px 48px rgba(255, 193, 7, 0.5);">
					<span style="font-size: 14px;margin-right: 10px;font-weight: 600;">ℹ️</span>
					<span>
						<strong style="color: #3a4547;font-size: 16px;font-weight: 700;">
							Что такое Company ID?
						</strong><br>
						<span style="font-size: 12px;font-weight: 600;color: #828687;margin-right: 10px;">
							Company ID — это уникальный идентификатор компании на нашем сайте. 
							Он присваивается только зарегистрированным компаниям, которые прошли процесс создания на нашей платформе.
						</span>
					</span>
				</div>

			</div>
			<button type="submit" class="signup_btn">Signup</button>
		</form>
	
	<!-- <img src="./static/images/azariel-titan-wallpaper-3840px.jpg"  alt="azariel-titan-wallpaper-3840px" title="azariel-titan-wallpaper-3840px"/> -->
	<!--
	<script src="./static/js/globals.js"></script>
	<script src="./static/js/signup/signup.js"></script>
	-->
	<script>
const role_select=document.querySelector('#role');

const director_inp=document.querySelector('#director_id');
const err_director_ctrl=document.querySelector('.err_director-ctrl');
const err_company_name=document.querySelector('.err_company_name');
const company_name=document.querySelector('#company_name');
const company_id=document.querySelector('#company_id');


function role_ctrl(el){
	if(el.value==='employee'){
		director_inp.disabled=false
		err_director_ctrl.innerHTML=''

		company_id.disabled=false
		company_name.disabled=true
		err_company_name.innerHTML='You need to be a director to enter the company name.'
	}else{
		director_inp.disabled=true
		err_director_ctrl.innerHTML='If you are not the director, change the Role field.'

		company_name.disabled=false

		company_id.disabled=true
		err_company_name.innerHTML=''
	}
}

role_select.addEventListener('change',e=>{
	role_ctrl(e.target)
})

window.onload=async function(){
	role_ctrl(director_inp)
}
	</script>
	
<?php require_once __DIR__.'/global/doctype_close.php'; ?>