<?php require_once __DIR__.'/csrf.php'; ?>
<!DOCTYPE html>
<html>
<head>
	  <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  
	  <!-- Краткое описание страницы -->
	  <meta name="description" content=""/>
	  <!-- Ключевые слова страницы, не больше 20-->
	  <meta name="keywords" content=""/>
	  
	  
	  <!-- Запрет индексации ссылок и изображении на странице -->
	  <meta name="robots" content="noimageindex, nofollow"/>
	  
	  <!-- Автор страницы -->
	  <meta name="Author" content=""/>
	  <!-- Авторские права -->
	  <meta name="Copyright" content=""/>
	  <!-- Адресс автора -->
	  <meta name="Address" content=""/>
	  
	  <title><?= $this->title;?></title>
	  