<?php
$_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Генерация случайного токена
// важное напомнить сделать страницу
?>