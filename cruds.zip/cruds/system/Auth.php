<?php

class Auth{

    public static function has_auth(){
        if(!isset($_SESSION['user_id'])){
            self::go_to("Location: http://localhost/cruds/signin");
        }
    }

    public static function who_auth(){
        if(isset($_SESSION['admin_id'])){
            self::go_to("Location: http://localhost/cruds/admin");
        }
        if(isset($_SESSION['user_id'])){
            self::go_to("Location: http://localhost/cruds/user");
        }
    }

    public static function go_to($location){
        header($location); // Перенаправление на страницу пользователя
        exit();
    }
}