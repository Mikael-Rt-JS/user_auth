<?php

class UserCtrl {
	public $title='User page';
	
	
    public function index() {
		global $connection;
		/*$query = $connection->query('SELECT * FROM users WHERE id=?');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);*/
		//var_dump($rows);

		Auth::has_auth();

		// Данные из сессии
		$user_id = $_SESSION['user_id'];
		$role = $_SESSION['role'];
		$director_id = $_SESSION['director_id'] ?? null;
		$company_id = $_SESSION['company_id'] ?? null;

		$sql="
		SELECT 
			u.id AS user_id, 
			u.name AS user_name, 
			u.surname, 
			u.role, 
			u.director_id, 
			u.active, 
			c.company_name, 
			c.id AS company_id
		FROM users u
		LEFT JOIN companies c ON u.company_id = c.id
		WHERE 
			u.id = :user_id 
			AND u.role = :role 
			AND (u.director_id = :director_id OR u.director_id IS NULL)
			AND (u.company_id = :company_id OR u.company_id IS NULL);
	";

		$stmt = $connection->prepare($sql);
		$stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
		$stmt->bindParam(':role', $role, PDO::PARAM_STR);
		// Для director_id
		if ($director_id === null) {
			$stmt->bindValue(':director_id', null, PDO::PARAM_NULL);
		} else {
			$stmt->bindValue(':director_id', $director_id, PDO::PARAM_INT);
		}

		// Для company_id
		if ($company_id === null) {
			$stmt->bindValue(':company_id', null, PDO::PARAM_NULL);
		} else {
			$stmt->bindValue(':company_id', $company_id, PDO::PARAM_INT);
		}

		// Выполнение запроса
		$stmt->execute();

		// Получение результата
		// $stmt->fetch(PDO::FETCH_ASSOC);
		// fetch(PDO::FETCH_OBJ)
		// fetch вернут дублированный оба вместе в одном
		$user = $stmt->fetch(PDO::FETCH_ASSOC);

		// переходим к представлению
		 include './citadel/views/user.php';
    }
	
	public function post_router(){
		// $inputData = file_get_contents('php://input');
		// $data = json_decode($inputData, true);
		$post = json_decode(file_get_contents('php://input'),true);

		if(!empty($post['get_employee_test'])){
			$this->get_employee_test();
			//echo json_encode(["employee"=>[1,2,23]]);
		}else{
			echo json_encode(['status'=>404,'post'=>$post]);
		}
	}

	public function get_employee_test(){
		global $connection;
		$director_id=$_SESSION['user_id'];
		$company_id=$_SESSION['company_id'];

		// Ограничение на 10 строк
		$limit = 10;

		 // Подготовленный запрос
		 $sql = "SELECT * FROM users WHERE director_id = :director_id AND company_id = :company_id LIMIT :limit";

		 try {
			// Подготовка запроса
			$stmt = $connection->prepare($sql);
		
			// Привязываем параметры
			$stmt->bindParam(':director_id', $director_id, PDO::PARAM_INT);
			$stmt->bindParam(':company_id', $company_id, PDO::PARAM_INT);
			$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
		
			// Выполнение запроса
			$stmt->execute();

			// Получаем результат
			$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

			// Проверяем, если данные найдены
			if (count($users) > 0) {
				//my| $usersEmployee=[];
				//my| $usersEmployee[]=$users;

				// foreach ($users as $user) {
				// 	echo "ID: " . $user['id'] . " - Имя: " . $user['name'] . "<br>";
				// }
				echo json_encode(['users'=>$users]);
			} else {
				echo json_encode(['users'=>[]]);
			}
		} catch (PDOException $e) {
			echo json_encode(['message_problem'=>'Ошибка подключения или запроса:'.$e->getMessage()]);
		}
		
		/*
		$query = $connection->query('SELECT * FROM users WHERE director_id=?');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		*/
		// echo json_encode(["employee"=>['us1','us2','us3']]);
	}

	/*
    public function index() {
		global $connection;
		if(array_key_exists('user_signin',$_SESSION)){
			$userInfo=$this->getUser($connection,$_SESSION['user_signin']);
		
			//var_dump($userInfo);
			
			// echo "GET - Главная страница";
			
			// переходим к представлению
			include './citadel/views/user.php';
		}else{
			header('Location: http://localhost/foryourbusiness/signin');
			exit();
		}
    }

	public function test(){
		echo '0o0';
	}
	
	public function getUser($connection){
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		return $rows;
	}
	*/
}