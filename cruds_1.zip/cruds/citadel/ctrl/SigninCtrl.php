<?php

class SigninCtrl {
	public $title='CITADEL MINI-FRAMEWORK';
	
	public function index() {

		Auth::who_auth();

		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		//var_dump($rows);
		
		
		// переходим к представлению
		include './citadel/views/signin.php';
    }

	public function signin_submit(){
		global $connection;

		if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
			die("Ошибка CSRF: Токен неверный.");
		}
		
		// Получаем данные из формы
		$email = $_POST['email'];
		$password = $_POST['password'];
		$company_id = $_POST['company_id'] ?? null;
		$director_id = $_POST['director_id'] ?? null;


		try {
			// Подготовленный запрос для проверки пользователя по email
			//$stmt = $connection->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
			// Строим базовый запрос
			$query = "SELECT * FROM users WHERE email = :email";


			if ($director_id == '') {
				$director_id=null;
			}
			if ($company_id == '') {
				$company_id=null;
			}

			// Учитываем company_id и director_id, если они переданы
			if ($company_id !== null) {
				$query .= " AND company_id = :company_id";
			}
			if ($director_id !== null) {
				$query .= " AND director_id = :director_id";
			}

			// Подготовка запроса
			$stmt = $connection->prepare($query);
			$stmt->bindParam(':email', $email, PDO::PARAM_STR);
			if ($company_id !== null) {
				$stmt->bindParam(':company_id', $company_id);
			}
			if ($director_id !== null) {
				$stmt->bindParam(':director_id', $director_id);
			}
			$stmt->execute();
		
			// Проверяем, найден ли пользователь с таким email
			if ($stmt->rowCount() > 0) {
				$user = $stmt->fetch(PDO::FETCH_ASSOC);
		
				// Проверяем совпадение пароля
				// Здесь предполагается, что пароль в базе данных захеширован
				if (password_verify($password, $user['password'])) {
					// Успешный вход - устанавливаем сессионные данные
					//$_SESSION['user_id'] = $user['id'];
					//$_SESSION['email'] = $user['email'];
					$_SESSION['user_id']=$user['id'];
					$_SESSION['role']=$user['role'];
					$_SESSION['company_id']=$user['company_id'] ?? null; // 'NULL'
					$_SESSION['director_id']=$user['director_id'] ?? null;// 'NULL'
					
					// Перенаправляем на личную страницу или другую страницу
					header('Location: http://localhost/cruds/user');
					exit();
				} else {
					// Неверный пароль
					$_SESSION['errors']['password'] = 'Неверный пароль.';

					header('Location: http://localhost/cruds/signin');
					exit();
				}
			} else {
				$_SESSION['errors']['email'] = 'Пользователь с таким email не найден.';
				
				header('Location: http://localhost/cruds/signin');
				exit();
			}
		} catch (PDOException $e) {
			// Обработка ошибок
			echo 'Ошибка: ' . $e->getMessage();
		}

	}
}