<?php

class AuthCtrl{

    // Метод для выхода
    public function logout() {
        session_start();

        // Удаляем все данные из сессии
        session_unset();

        // Уничтожаем сессию
        session_destroy();

        // Устанавливаем заголовок ответа и перенаправляем на страницу входа
        header("Location: http://localhost/cruds/signin"); // Перенаправление на страницу входа
        exit();
    }
}