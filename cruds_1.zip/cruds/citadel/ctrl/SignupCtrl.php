<?php

class SignupCtrl {
	public $title='CITADEL MINI-FRAMEWORK';
	
	public function index() {
		Auth::who_auth();

		global $connection;
		$query = $connection->query('SELECT * FROM users');
		$rows = $query->fetchAll(PDO::FETCH_ASSOC);
		

		// переходим к представлению
		include './citadel/views/signup.php';
    }
	
	public function signup_submit(){
		global $connection;

		if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
			die("Ошибка CSRF: Токен неверный.");
		}

		$validator = new Validate();

		if($_POST['role']=='director'){
			// Проверяем все поля
			$validator->validateName($_POST['name'] ?? '')
			->validateSurName($_POST['surname'] ?? '')
			->validatePhone($_POST['phone'] ?? '')
			->validateEmail($_POST['email'] ?? '')
			->validatePassword($_POST['password'] ?? '')
			->validateRepeatPassword($_POST['password'] ?? '', $_POST['repeat_password'] ?? '')
			->validateCompanyName($_POST['company_name'] ?? '');

			// Проверяем наличие ошибок
			if ($validator->hasErrors()) {
				// Если ошибки есть, сохраняем их в сессии и редиректим обратно
				$validator->storeErrorsInSession();
				header("Location: http://localhost/cruds/signup"); // Редирект на страницу регистрации
				exit();
			} else {
				// Если ошибок нет, записываем данные в базу данных
				//$db = Database::getInstance();

				$dataCompany = [
					'company_name'=> $_POST['company_name']
				];

				MySQL::insertCompany($connection,$dataCompany);
				// Получаем ID последней вставленной записи
				$company_id=$connection->lastInsertId();


				// Подготовка данных для вставки
				$data = [
					'name' => $_POST['name'],
					'surname' => $_POST['surname'],
					'phone' => $_POST['phone'],
					'email' => $_POST['email'],
					'password' => password_hash($_POST['password'], PASSWORD_DEFAULT), // Хешируем пароль
					'role'=> $_POST['role'],
					'company_id'=>$company_id
				];

				MySQL::insertUserDi($connection,$data);

				// Получаем ID последней вставленной записи
				$user_id=$connection->lastInsertId();

				MySQL::updateCompany($connection,$company_id,$user_id);

				$_SESSION['user_id']=$user_id;
				$_SESSION['role']=$_POST['role'];
				$_SESSION['company_id']=$company_id ?? 'NULL';
				$_SESSION['director_id']='NULL';

				// Очищаем ошибки из сессии и перенаправляем на страницу с успешной регистрацией
				$validator->clearErrorsFromSession();
				header("Location: http://localhost/cruds/user"); // Перенаправление на страницу успеха
				exit();
			}
			// КОНЕЦ 1-й валидации

		}else if($_POST['role']=='employee'){
			// Проверяем все поля
			$validator->validateName($_POST['name'] ?? '')
			->validateSurName($_POST['surname'] ?? '')
			->validatePhone($_POST['phone'] ?? '')
			->validateEmail($_POST['email'] ?? '')
			->validateRepeatPassword($_POST['password'] ?? '', $_POST['repeat_password'] ?? '')
			->validateDirectorId($_POST['director_id'] ?? null)
			->validateCompanyId($_POST['company_id'] ?? null);

			// Проверяем наличие ошибок
			if ($validator->hasErrors()) {
				// Если ошибки есть, сохраняем их в сессии и редиректим обратно
				$validator->storeErrorsInSession();
				header("Location: http://localhost/cruds/signup"); // Редирект на страницу регистрации
				exit();
			} else {
				// Если ошибок нет, записываем данные в базу данных

				// Подготовка данных для вставки
				$data = [
					'name' => $_POST['name'],
					'surname' => $_POST['surname'],
					'phone' => $_POST['phone'],
					'email' => $_POST['email'],
					'password' => password_hash($_POST['password'], PASSWORD_DEFAULT), // Хешируем пароль
					'role'=> $_POST['role'],
					'director_id'=>$_POST['director_id'],
					'company_id'=>$_POST['company_id']
				];


				MySQL::insertUserEmp($connection,$data);

				// Получаем ID последней вставленной записи
				$user_id=$connection->lastInsertId();

				$_SESSION['user_id']=$user_id;
				$_SESSION['role']=$_POST['role'];
				$_SESSION['company_id']=$_POST['company_id'] ?? null;
				$_SESSION['director_id']=$_POST['director_id'] ?? null;

				// Очищаем ошибки из сессии и перенаправляем на страницу с успешной регистрацией
				$validator->clearErrorsFromSession();
				header("Location: http://localhost/cruds/user"); // Перенаправление на страницу успеха
				exit();
			}
		}
		
		/*else{
			ini_set('display_errors', 1);
			error_reporting(E_ALL);
			var_dump(345);
		}*/
		

		
		
	}

}
