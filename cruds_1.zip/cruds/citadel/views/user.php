<?php require_once __DIR__.'/global/doctype_open.php'; ?>
	  
	<!-- FONTS -->
  
	<!-- Inter&Rubik Moonrocks -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Rubik+Moonrocks&display=swap" rel="stylesheet">
  
	<link href="./static/css/globals/reset.css" rel="stylesheet" text="text/css"/>
	<link href="./static/css/globals/globals.css" rel="stylesheet" text="text/css"/>
	
    <style>

    </style>
</head>
<body>
	
	<h1>User page</h1>
	<a id="logoutLink" href="#">Logout</a>


    <div>
        <b>Company ID:</b> 
        <span><?= $user["company_id"];?></span>
    </div>

    <div>
        <b>Company name:</b> 
        <span><?= $user["company_name"];?></span>
    </div>

    <div>
        <b>User ID:</b> 
        <span><?= $user["user_id"];?></span>
    </div>

    <div>
        <b>Full name:</b> 
        <span><?= $user["user_name"].$user["surname"];?></span>
    </div>
    
    <div>
        <b>Role:</b> 
        <i><?= $user["role"]; ?></i>
    </div>

    <?php
    
echo '<pre>';
// var_dump($_SESSION['director_id']===null);
// var_dump($_SESSION);
// var_dump($user);
	?>
	
	<script>



// logout
document.getElementById('logoutLink').addEventListener('click', function(event) {
    event.preventDefault(); // Останавливаем стандартное поведение ссылки (переход по URL)

    // Отправляем запрос на сервер с помощью Fetch API (POST)
    fetch('/cruds/logout', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded', // Указываем тип контента
        }
    })
    .then(response => {
        // После успешного выполнения запроса перенаправляем пользователя на страницу входа
        if (response.ok) {
            window.location.href = 'http://localhost/cruds/signin'; // Перенаправляем на страницу входа
        }
    })
    .catch(error => {
        console.error('Ошибка при выходе:', error);
    });
});




// ЗАПРОССЫ тренинг с php js
class Req{
    get_Employee(path,){

    }
}

window.onload= async ()=>{
    let test=await fetch('http://localhost/cruds/user',{
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ 
            "get_employee_test": "true",

        })
    })
    .then(res=>res.json())
    .then(data=>data)
    .catch(err=>console.log(err))

    if(await test){
        console.log(test);
    }
}
	</script>
<?php require_once __DIR__.'/global/doctype_close.php'; ?>