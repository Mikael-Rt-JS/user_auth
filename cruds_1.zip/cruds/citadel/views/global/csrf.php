<?php
$_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Генерация случайного токена
// важное напомнить сделать страницу

//<!--  -->
//<input type="hidden" name="csrf_token" value="?php echo $_SESSION['csrf_token']; ?" />

/*
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
			die("Ошибка CSRF: Токен неверный.");
		}
*/

// ДЛЯ JS
// <meta name="csrf-token" content="<?php echo $_SESSION['csrf_token']; >">
?>