<?php

class Validate{

    private $errors = [];

    // Метод для очистки входных данных
    private function sanitize_input($data) {
        $data = trim($data); // Убираем пробелы по краям
        $data = htmlspecialchars($data); // Убираем HTML теги
        $data = stripslashes($data); // Убираем слэши
        return $data;
    }

    // Метод для проверки имени
    public function validateName($name) {
        $name = $this->sanitize_input($name);

        if (empty($name)) {
            $this->errors['name'] = "Поле 'Имя' не должно быть пустым";
        } elseif (strlen($name) < 3 || strlen($name) > 250) {
            $this->errors['name'] = "Поле 'Имя' должно быть от 3 до 250 символов";
        }

        return $this;
    }

    // Метод для проверки второго имени или фамилия
    public function validateSurName($surname) {
        $name = $this->sanitize_input($surname);

        if (empty($surname)) {
            $this->errors['surname'] = "Поле 'Фамилия' не должно быть пустым";
        } elseif (strlen($name) < 3 || strlen($name) > 250) {
            $this->errors['surname'] = "Поле 'Фамилия' должно быть от 3 до 250 символов";
        }

        return $this;
    }

    // Метод для проверки имени
    public function validateCompanyName($company_name) {
        $company_name = $this->sanitize_input($company_name);

        if (strlen($company_name) > 250) {
            $this->errors['company_name'] = "Поле 'Название компании' не должно быть больше 250 символов";
        }

        return $this;
    }

    // Метод для проверки телефона
    public function validatePhone($phone) {
        $phone = $this->sanitize_input($phone);

        if (empty($phone)) {
            $this->errors['phone'] = "Поле 'Телефон' не должно быть пустым";
        } elseif (!preg_match("/^[\d+]+$/", $phone)) {
            $this->errors['phone'] = "Поле 'Телефон' должно содержать только цифры и знак '+'";
        }

        return $this;
    }

    // Метод для проверки ID директора
    public function validateDirectorId($directore_id) {
        $directore_id = $this->sanitize_input($directore_id);

        return $this;
    }
	
    // Метод для проверки ID компании
    public function validateCompanyId($directore_id) {
        $directore_id = $this->sanitize_input($directore_id);

        return $this;
    }
    
    // Метод для проверки email
    public function validateEmail($email) {
        $email = $this->sanitize_input($email);

        if (empty($email)) {
            $this->errors['email'] = "Поле 'Email' не должно быть пустым";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = "Поле 'Email' должно быть в корректном формате";
        } elseif (strlen($email) < 3 || strlen($email) > 250) {
            $this->errors['email'] = "Поле 'Email' должно быть от 3 до 250 символов";
        }

        return $this;
    }

    // Метод для проверки пароля
    public function validatePassword($password) {
        $password = $this->sanitize_input($password);

        if (empty($password)) {
            $this->errors['password'] = "Поле 'Пароль' не должно быть пустым";
        } elseif (!preg_match("/^[a-zA-Z0-9]+$/", $password)) {
            $this->errors['password'] = "Поле 'Пароль' должно содержать только латинские символы и цифры";
        } elseif (strlen($password) < 6 || strlen($password) > 250) {
            $this->errors['password'] = "Поле 'Пароль' должно быть от 6 до 250 символов";
        }

        return $this;
    }

    // Метод для проверки повторного пароля
    public function validateRepeatPassword($password, $repeatPassword) {
        if ($password !== $repeatPassword) {
            $this->errors['repeat_password'] = "Пароли не совпадают";
        }

        return $this;
    }

    // Метод для получения всех ошибок
    public function getErrors() {
        return $this->errors;
    }

    // Метод для проверки, есть ли ошибки
    public function hasErrors() {
        return !empty($this->errors);
    }

    // Метод для отображения ошибок (например, под полем)
    public function showErrors() {
        if ($this->hasErrors()) {
            foreach ($this->errors as $field => $error) {
                echo "<div class='error' id='error-{$field}' style='color: red;'>{$error}</div>";
            }
        }
    }

    // Метод для сохранения ошибок в сессии
    public function storeErrorsInSession() {
        $_SESSION['errors'] = $this->errors;
    }

    // Метод для очистки ошибок из сессии
    public function clearErrorsFromSession() {
        unset($_SESSION['errors']);
    }
}